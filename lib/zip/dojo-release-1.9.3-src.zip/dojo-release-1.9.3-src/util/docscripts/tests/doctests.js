dojo.provide("util.docscripts.tests.doctests");

dojo.require("util.docscripts.tests.basic");
