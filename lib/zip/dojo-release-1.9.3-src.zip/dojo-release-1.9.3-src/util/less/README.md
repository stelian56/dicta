less.js
=======

The **dynamic** stylesheet language.

<http://lesscss.org>

about
-----

This is the JavaScript, and now official, stable version of LESS.

For more information, visit <http://lesscss.org>.

license
-------

See `LICENSE` file.

> Copyright (c) 2009-2011 Alexis Sellier
