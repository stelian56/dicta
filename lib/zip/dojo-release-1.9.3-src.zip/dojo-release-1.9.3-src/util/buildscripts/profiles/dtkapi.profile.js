dependencies = {
	layers: [
		{
			name: "../dojo/dtkapi.js",
			dependencies: [
				"dojox.widget.Dialog",
				"dojo.fx.easing"
			]
		}
	],

	prefixes: [
		[ "dijit", "../dijit" ],
		[ "dojox", "../dojox" ]
	]
};

